import React, {PureComponent} from 'react'
// import style from '@/css/index.css'
import { Button } from 'antd-mobile';
export default class Home extends PureComponent {
	render(){
		return (
			<div className='page-box'>
				年后屌丝发货
				<div className='text-for'>this is homeqwe123e</div>
				<Button>start</Button>
			</div>
		)
	}
}