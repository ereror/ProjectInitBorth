import common from 'services/common'
export const GET_USER_INFO = "userInfo/GET_USER_INFO";

export function getUserInfo() {
	return dispatch => {
		common.getUserInfo().then(res => {
			console.log(res)
			let data = JSON.parse(res.request.responseText)
            dispatch({
                type: GET_USER_INFO,
                payload: data
            });			
		})
	}
}