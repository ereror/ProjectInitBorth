import React from 'react'

export default () => {
	return (<div>Loading...</div>)
}