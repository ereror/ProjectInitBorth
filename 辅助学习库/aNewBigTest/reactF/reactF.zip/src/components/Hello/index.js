import React, { PureComponent } from 'react'

export default class Hello extends PureComponent {
	render(){
		return (
			<div>
				Hello,
			</div>
		)
	}
}