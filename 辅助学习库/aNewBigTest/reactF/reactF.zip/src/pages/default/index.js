import React, {PureComponent} from 'react'

export default class NotFound extends PureComponent {
	render() {
		return (
			<div className='default-404'>建设中...</div>
		)
	}
}